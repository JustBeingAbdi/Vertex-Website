<?php
/**
 * Author: Blue
 * Version : 0.1
 */

session_start();
session_destroy(); //disconnects
header('Location: https://bluebot.pw');
?>